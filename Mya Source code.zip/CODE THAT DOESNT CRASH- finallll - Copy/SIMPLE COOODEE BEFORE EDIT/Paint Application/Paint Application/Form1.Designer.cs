﻿namespace Paint_Application
{
    partial class MainApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pencil = new System.Windows.Forms.Button();
            this.paintbrush = new System.Windows.Forms.Button();
            this.inkpen = new System.Windows.Forms.Button();
            this.crayon = new System.Windows.Forms.Button();
            this.bucket = new System.Windows.Forms.Button();
            this.scissor = new System.Windows.Forms.Button();
            this.magnify = new System.Windows.Forms.Button();
            this.straightline = new System.Windows.Forms.Button();
            this.textbox = new System.Windows.Forms.Button();
            this.textsize = new System.Windows.Forms.Button();
            this.colourwheel = new System.Windows.Forms.Button();
            this.table = new System.Windows.Forms.Button();
            this.attachment = new System.Windows.Forms.Button();
            this.fineline = new System.Windows.Forms.Button();
            this.spraypaint = new System.Windows.Forms.Button();
            this.watercolour = new System.Windows.Forms.Button();
            this.eraser = new System.Windows.Forms.Button();
            this.dropper = new System.Windows.Forms.Button();
            this.select = new System.Windows.Forms.Button();
            this.shapes = new System.Windows.Forms.Button();
            this.curvedline = new System.Windows.Forms.Button();
            this.font = new System.Windows.Forms.Button();
            this.colourpalette = new System.Windows.Forms.Button();
            this.stamp = new System.Windows.Forms.Button();
            this.ruler = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.file = new System.Windows.Forms.Button();
            this.edit = new System.Windows.Forms.Button();
            this.view = new System.Windows.Forms.Button();
            this.image = new System.Windows.Forms.Button();
            this.window = new System.Windows.Forms.Button();
            this.mode = new System.Windows.Forms.Button();
            this.help = new System.Windows.Forms.Button();
            this.drawingboard = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.drawingboard)).BeginInit();
            this.SuspendLayout();
            // 
            // pencil
            // 
            this.pencil.Image = global::Paint_Application.Properties.Resources.PENCIL;
            this.pencil.Location = new System.Drawing.Point(6, 618);
            this.pencil.Name = "pencil";
            this.pencil.Size = new System.Drawing.Size(87, 107);
            this.pencil.TabIndex = 0;
            this.pencil.UseVisualStyleBackColor = true;
            this.pencil.Click += new System.EventHandler(this.pencil_Click);
            // 
            // paintbrush
            // 
            this.paintbrush.Image = global::Paint_Application.Properties.Resources.PAINTBRUSH;
            this.paintbrush.Location = new System.Drawing.Point(99, 618);
            this.paintbrush.Name = "paintbrush";
            this.paintbrush.Size = new System.Drawing.Size(94, 107);
            this.paintbrush.TabIndex = 1;
            this.paintbrush.UseVisualStyleBackColor = true;
            // 
            // inkpen
            // 
            this.inkpen.Image = global::Paint_Application.Properties.Resources.INKPEN;
            this.inkpen.Location = new System.Drawing.Point(199, 618);
            this.inkpen.Name = "inkpen";
            this.inkpen.Size = new System.Drawing.Size(105, 107);
            this.inkpen.TabIndex = 2;
            this.inkpen.UseVisualStyleBackColor = true;
            // 
            // crayon
            // 
            this.crayon.Image = global::Paint_Application.Properties.Resources.CRAYON;
            this.crayon.Location = new System.Drawing.Point(310, 618);
            this.crayon.Name = "crayon";
            this.crayon.Size = new System.Drawing.Size(77, 107);
            this.crayon.TabIndex = 3;
            this.crayon.UseVisualStyleBackColor = true;
            // 
            // bucket
            // 
            this.bucket.Image = global::Paint_Application.Properties.Resources.BUCKET;
            this.bucket.Location = new System.Drawing.Point(393, 618);
            this.bucket.Name = "bucket";
            this.bucket.Size = new System.Drawing.Size(104, 107);
            this.bucket.TabIndex = 4;
            this.bucket.UseVisualStyleBackColor = true;
            this.bucket.Click += new System.EventHandler(this.bucket_Click);
            // 
            // scissor
            // 
            this.scissor.Image = global::Paint_Application.Properties.Resources.SCISSORS;
            this.scissor.Location = new System.Drawing.Point(503, 618);
            this.scissor.Name = "scissor";
            this.scissor.Size = new System.Drawing.Size(89, 107);
            this.scissor.TabIndex = 5;
            this.scissor.UseVisualStyleBackColor = true;
            // 
            // magnify
            // 
            this.magnify.Image = global::Paint_Application.Properties.Resources.MAGNIFYGLASS;
            this.magnify.Location = new System.Drawing.Point(598, 618);
            this.magnify.Name = "magnify";
            this.magnify.Size = new System.Drawing.Size(103, 107);
            this.magnify.TabIndex = 6;
            this.magnify.UseVisualStyleBackColor = true;
            // 
            // straightline
            // 
            this.straightline.Image = global::Paint_Application.Properties.Resources.STRAIGHT_LINE;
            this.straightline.Location = new System.Drawing.Point(707, 618);
            this.straightline.Name = "straightline";
            this.straightline.Size = new System.Drawing.Size(83, 107);
            this.straightline.TabIndex = 7;
            this.straightline.UseVisualStyleBackColor = true;
            this.straightline.Click += new System.EventHandler(this.straightline_Click);
            // 
            // textbox
            // 
            this.textbox.Image = global::Paint_Application.Properties.Resources.TEXTBOX;
            this.textbox.Location = new System.Drawing.Point(797, 618);
            this.textbox.Name = "textbox";
            this.textbox.Size = new System.Drawing.Size(80, 107);
            this.textbox.TabIndex = 8;
            this.textbox.UseVisualStyleBackColor = true;
            // 
            // textsize
            // 
            this.textsize.Image = global::Paint_Application.Properties.Resources.TEXTSIZE;
            this.textsize.Location = new System.Drawing.Point(884, 618);
            this.textsize.Name = "textsize";
            this.textsize.Size = new System.Drawing.Size(65, 107);
            this.textsize.TabIndex = 9;
            this.textsize.UseVisualStyleBackColor = true;
            // 
            // colourwheel
            // 
            this.colourwheel.Image = global::Paint_Application.Properties.Resources.COLOURWHEEL;
            this.colourwheel.Location = new System.Drawing.Point(955, 618);
            this.colourwheel.Name = "colourwheel";
            this.colourwheel.Size = new System.Drawing.Size(91, 107);
            this.colourwheel.TabIndex = 10;
            this.colourwheel.UseVisualStyleBackColor = true;
            // 
            // table
            // 
            this.table.Image = global::Paint_Application.Properties.Resources.TABLE;
            this.table.Location = new System.Drawing.Point(1052, 618);
            this.table.Name = "table";
            this.table.Size = new System.Drawing.Size(121, 107);
            this.table.TabIndex = 11;
            this.table.UseVisualStyleBackColor = true;
            // 
            // attachment
            // 
            this.attachment.Image = global::Paint_Application.Properties.Resources.ATTACHMENT;
            this.attachment.Location = new System.Drawing.Point(1179, 618);
            this.attachment.Name = "attachment";
            this.attachment.Size = new System.Drawing.Size(89, 107);
            this.attachment.TabIndex = 12;
            this.attachment.UseVisualStyleBackColor = true;
            // 
            // fineline
            // 
            this.fineline.Image = global::Paint_Application.Properties.Resources.THIN;
            this.fineline.Location = new System.Drawing.Point(10, 741);
            this.fineline.Name = "fineline";
            this.fineline.Size = new System.Drawing.Size(98, 111);
            this.fineline.TabIndex = 13;
            this.fineline.UseVisualStyleBackColor = true;
            // 
            // spraypaint
            // 
            this.spraypaint.Image = global::Paint_Application.Properties.Resources.SPRAYCAN;
            this.spraypaint.Location = new System.Drawing.Point(114, 741);
            this.spraypaint.Name = "spraypaint";
            this.spraypaint.Size = new System.Drawing.Size(79, 111);
            this.spraypaint.TabIndex = 14;
            this.spraypaint.UseVisualStyleBackColor = true;
            // 
            // watercolour
            // 
            this.watercolour.Image = global::Paint_Application.Properties.Resources.WATERCOLOUR;
            this.watercolour.Location = new System.Drawing.Point(199, 741);
            this.watercolour.Name = "watercolour";
            this.watercolour.Size = new System.Drawing.Size(105, 111);
            this.watercolour.TabIndex = 15;
            this.watercolour.UseVisualStyleBackColor = true;
            // 
            // eraser
            // 
            this.eraser.Image = global::Paint_Application.Properties.Resources.ERASER;
            this.eraser.Location = new System.Drawing.Point(310, 741);
            this.eraser.Name = "eraser";
            this.eraser.Size = new System.Drawing.Size(86, 111);
            this.eraser.TabIndex = 16;
            this.eraser.UseVisualStyleBackColor = true;
            // 
            // dropper
            // 
            this.dropper.Image = global::Paint_Application.Properties.Resources.DROPPER;
            this.dropper.Location = new System.Drawing.Point(402, 741);
            this.dropper.Name = "dropper";
            this.dropper.Size = new System.Drawing.Size(86, 111);
            this.dropper.TabIndex = 17;
            this.dropper.UseVisualStyleBackColor = true;
            // 
            // select
            // 
            this.select.Image = global::Paint_Application.Properties.Resources.SELECT;
            this.select.Location = new System.Drawing.Point(494, 741);
            this.select.Name = "select";
            this.select.Size = new System.Drawing.Size(86, 111);
            this.select.TabIndex = 18;
            this.select.UseVisualStyleBackColor = true;
            // 
            // shapes
            // 
            this.shapes.Image = global::Paint_Application.Properties.Resources.SHAPES;
            this.shapes.Location = new System.Drawing.Point(586, 741);
            this.shapes.Name = "shapes";
            this.shapes.Size = new System.Drawing.Size(95, 111);
            this.shapes.TabIndex = 19;
            this.shapes.UseVisualStyleBackColor = true;
            // 
            // curvedline
            // 
            this.curvedline.Image = global::Paint_Application.Properties.Resources.CURVEDLINE;
            this.curvedline.Location = new System.Drawing.Point(687, 741);
            this.curvedline.Name = "curvedline";
            this.curvedline.Size = new System.Drawing.Size(86, 111);
            this.curvedline.TabIndex = 20;
            this.curvedline.UseVisualStyleBackColor = true;
            // 
            // font
            // 
            this.font.Image = global::Paint_Application.Properties.Resources.FONT;
            this.font.Location = new System.Drawing.Point(779, 741);
            this.font.Name = "font";
            this.font.Size = new System.Drawing.Size(97, 111);
            this.font.TabIndex = 21;
            this.font.UseVisualStyleBackColor = true;
            // 
            // colourpalette
            // 
            this.colourpalette.Image = global::Paint_Application.Properties.Resources.COLOURPALETTE;
            this.colourpalette.Location = new System.Drawing.Point(882, 741);
            this.colourpalette.Name = "colourpalette";
            this.colourpalette.Size = new System.Drawing.Size(109, 111);
            this.colourpalette.TabIndex = 22;
            this.colourpalette.UseVisualStyleBackColor = true;
            this.colourpalette.Click += new System.EventHandler(this.button10_Click);
            // 
            // stamp
            // 
            this.stamp.Image = global::Paint_Application.Properties.Resources.STAMP;
            this.stamp.Location = new System.Drawing.Point(997, 741);
            this.stamp.Name = "stamp";
            this.stamp.Size = new System.Drawing.Size(86, 111);
            this.stamp.TabIndex = 23;
            this.stamp.UseVisualStyleBackColor = true;
            this.stamp.Click += new System.EventHandler(this.button11_Click);
            // 
            // ruler
            // 
            this.ruler.Image = global::Paint_Application.Properties.Resources.RULER;
            this.ruler.Location = new System.Drawing.Point(1089, 741);
            this.ruler.Name = "ruler";
            this.ruler.Size = new System.Drawing.Size(93, 111);
            this.ruler.TabIndex = 24;
            this.ruler.UseVisualStyleBackColor = true;
            this.ruler.Click += new System.EventHandler(this.button12_Click);
            // 
            // exit
            // 
            this.exit.Image = global::Paint_Application.Properties.Resources.EXIT;
            this.exit.Location = new System.Drawing.Point(1188, 741);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(82, 111);
            this.exit.TabIndex = 25;
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.button13_Click);
            // 
            // file
            // 
            this.file.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.file.ForeColor = System.Drawing.Color.Black;
            this.file.Location = new System.Drawing.Point(6, 12);
            this.file.Name = "file";
            this.file.Size = new System.Drawing.Size(175, 56);
            this.file.TabIndex = 26;
            this.file.Text = "File";
            this.file.UseVisualStyleBackColor = true;
            // 
            // edit
            // 
            this.edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edit.ForeColor = System.Drawing.Color.Black;
            this.edit.Location = new System.Drawing.Point(184, 12);
            this.edit.Name = "edit";
            this.edit.Size = new System.Drawing.Size(175, 56);
            this.edit.TabIndex = 27;
            this.edit.Text = "Edit";
            this.edit.UseVisualStyleBackColor = true;
            // 
            // view
            // 
            this.view.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view.ForeColor = System.Drawing.Color.Black;
            this.view.Location = new System.Drawing.Point(365, 12);
            this.view.Name = "view";
            this.view.Size = new System.Drawing.Size(175, 56);
            this.view.TabIndex = 28;
            this.view.Text = "View";
            this.view.UseVisualStyleBackColor = true;
            // 
            // image
            // 
            this.image.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.image.ForeColor = System.Drawing.Color.Black;
            this.image.Location = new System.Drawing.Point(546, 12);
            this.image.Name = "image";
            this.image.Size = new System.Drawing.Size(175, 56);
            this.image.TabIndex = 29;
            this.image.Text = "Image";
            this.image.UseVisualStyleBackColor = true;
            // 
            // window
            // 
            this.window.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.window.ForeColor = System.Drawing.Color.Black;
            this.window.Location = new System.Drawing.Point(727, 12);
            this.window.Name = "window";
            this.window.Size = new System.Drawing.Size(175, 56);
            this.window.TabIndex = 30;
            this.window.Text = "Window";
            this.window.UseVisualStyleBackColor = true;
            // 
            // mode
            // 
            this.mode.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mode.ForeColor = System.Drawing.Color.Black;
            this.mode.Location = new System.Drawing.Point(908, 12);
            this.mode.Name = "mode";
            this.mode.Size = new System.Drawing.Size(175, 56);
            this.mode.TabIndex = 31;
            this.mode.Text = "Mode";
            this.mode.UseVisualStyleBackColor = true;
            // 
            // help
            // 
            this.help.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.help.ForeColor = System.Drawing.Color.Black;
            this.help.Location = new System.Drawing.Point(1089, 12);
            this.help.Name = "help";
            this.help.Size = new System.Drawing.Size(175, 56);
            this.help.TabIndex = 32;
            this.help.Text = "Help";
            this.help.UseVisualStyleBackColor = true;
            // 
            // drawingboard
            // 
            this.drawingboard.Location = new System.Drawing.Point(12, 92);
            this.drawingboard.Name = "drawingboard";
            this.drawingboard.Size = new System.Drawing.Size(1244, 509);
            this.drawingboard.TabIndex = 33;
            this.drawingboard.TabStop = false;
            this.drawingboard.MouseDown += new System.Windows.Forms.MouseEventHandler(this.drawingboard_MouseDown);
            this.drawingboard.MouseMove += new System.Windows.Forms.MouseEventHandler(this.drawingboard_MouseMove);
            this.drawingboard.MouseUp += new System.Windows.Forms.MouseEventHandler(this.drawingboard_MouseUp);
            // 
            // MainApp
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1268, 864);
            this.Controls.Add(this.drawingboard);
            this.Controls.Add(this.help);
            this.Controls.Add(this.mode);
            this.Controls.Add(this.window);
            this.Controls.Add(this.image);
            this.Controls.Add(this.view);
            this.Controls.Add(this.edit);
            this.Controls.Add(this.file);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.ruler);
            this.Controls.Add(this.stamp);
            this.Controls.Add(this.colourpalette);
            this.Controls.Add(this.font);
            this.Controls.Add(this.curvedline);
            this.Controls.Add(this.shapes);
            this.Controls.Add(this.select);
            this.Controls.Add(this.dropper);
            this.Controls.Add(this.eraser);
            this.Controls.Add(this.watercolour);
            this.Controls.Add(this.spraypaint);
            this.Controls.Add(this.fineline);
            this.Controls.Add(this.attachment);
            this.Controls.Add(this.table);
            this.Controls.Add(this.colourwheel);
            this.Controls.Add(this.textsize);
            this.Controls.Add(this.textbox);
            this.Controls.Add(this.straightline);
            this.Controls.Add(this.magnify);
            this.Controls.Add(this.scissor);
            this.Controls.Add(this.bucket);
            this.Controls.Add(this.crayon);
            this.Controls.Add(this.inkpen);
            this.Controls.Add(this.paintbrush);
            this.Controls.Add(this.pencil);
            this.ForeColor = System.Drawing.SystemColors.Window;
            this.Name = "MainApp";
            this.Text = "MainApp";
            ((System.ComponentModel.ISupportInitialize)(this.drawingboard)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button pencil;
        private System.Windows.Forms.Button paintbrush;
        private System.Windows.Forms.Button inkpen;
        private System.Windows.Forms.Button crayon;
        private System.Windows.Forms.Button bucket;
        private System.Windows.Forms.Button scissor;
        private System.Windows.Forms.Button magnify;
        private System.Windows.Forms.Button straightline;
        private System.Windows.Forms.Button textbox;
        private System.Windows.Forms.Button textsize;
        private System.Windows.Forms.Button colourwheel;
        private System.Windows.Forms.Button table;
        private System.Windows.Forms.Button attachment;
        private System.Windows.Forms.Button fineline;
        private System.Windows.Forms.Button spraypaint;
        private System.Windows.Forms.Button watercolour;
        private System.Windows.Forms.Button eraser;
        private System.Windows.Forms.Button dropper;
        private System.Windows.Forms.Button select;
        private System.Windows.Forms.Button shapes;
        private System.Windows.Forms.Button curvedline;
        private System.Windows.Forms.Button font;
        private System.Windows.Forms.Button colourpalette;
        private System.Windows.Forms.Button stamp;
        private System.Windows.Forms.Button ruler;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button file;
        private System.Windows.Forms.Button edit;
        private System.Windows.Forms.Button view;
        private System.Windows.Forms.Button image;
        private System.Windows.Forms.Button window;
        private System.Windows.Forms.Button mode;
        private System.Windows.Forms.Button help;
        private System.Windows.Forms.PictureBox drawingboard;
    }
}

