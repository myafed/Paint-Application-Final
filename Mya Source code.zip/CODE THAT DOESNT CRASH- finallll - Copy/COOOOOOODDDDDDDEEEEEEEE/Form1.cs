﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Paint_Application
{
    public partial class MainApp : Form
    {
       
        public Point current = new Point();
        public Point old = new Point();
        public Pen pen = new Pen(Color.Black, 10);
        public Graphics g;
        

        public MainApp()
        {
         
            
            InitializeComponent();
            g = this.CreateGraphics();
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            //Below will be code for the exit button to close the form 
            Close();
        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void drawingboard_MouseDown(object sender, MouseEventArgs e)
        {
            old = e.Location;
        }

        private void drawingboard_MouseMove(object sender, MouseEventArgs e)
        {
            if(e.Button==MouseButtons.Left)
            {
            current = e.Location;
            g.DrawLine(pen, old, current);
            old = current;
            }
        }

        private void drawingboard_MouseUp(object sender, MouseEventArgs e)
        {

        }

        private void pencil_Click(object sender, EventArgs e)
        {
            //below will allow pencil to be slected and used on drawing baord
            // paint = true;
            //Graphics g = drawingboard.CreateGraphics();
            // Pen pen = new Pen(Color.Black, 10);
            System.Drawing.Pen myPen;
            myPen = new System.Drawing.Pen(System.Drawing.Color.Black);
        }

        private void bucket_Click(object sender, EventArgs e)
        {
            //This will mean the graphics on the drawing board will be cleared completely
            Graphics g = drawingboard.CreateGraphics();
            g.Clear(drawingboard.BackColor);

        }

        private void straightline_Click(object sender, EventArgs e)
        {
            //below is code to draw automatically draw a line at certain co-ordinates in blac
            Graphics g = drawingboard.CreateGraphics();
            Brush line = new SolidBrush(Color.Black);
            Pen straightline = new Pen(Color.Black, 10);
            g.DrawLine(straightline, 10, 10, 40, 500);

        }

        private void file_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature is currently under maintenence");
        }

        private void edit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature is currently under maintenence");
        }

        private void view_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature is currently under maintenence");
        }

        private void image_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature is currently under maintenence");
        }

        private void window_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature is currently under maintenence");
        }

        private void mode_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature is currently under maintenence");
        }

        private void help_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature is currently under maintenence");
        }
    }
}
